
# Instrucciones para subir tu landing de CultivaTech 🚀

1. Ve a tu repositorio en GitHub: https://github.com/aitanayael/cultivatech
2. Haz clic en **choose your files**.
3. Selecciona el archivo **index.html**.
4. Da clic en **Commit changes**.
5. Ve a **Settings > Pages**.
6. En **Source**, selecciona **main** y **/(root)**.
7. Guarda los cambios y tu página estará en línea en:
   https://aitanayael.github.io/cultivatech/
